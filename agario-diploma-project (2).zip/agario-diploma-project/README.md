# Agar.io Diploma Project

1. `npm install`
2. Скопіюй `.env.example` → `.env`
3. `npm start`
4. Відкрий http://localhost:3000