const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const socket = io();

let myId = null;
let players = {};
let foods = [];
let cameraX = 0;
let cameraY = 0;
let mouseX = 0;
let mouseY = 0;

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

window.addEventListener('resize', () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});

document.getElementById('playBtn').addEventListener('click', () => {
  const nickname = document.getElementById('nickname').value.trim() || 'Гравець';
  document.getElementById('menu').style.display = 'none';
  socket.emit('setName', nickname);
});

socket.on('init', (data) => {
  myId = data.id;
  foods = data.foods;
});

socket.on('gameState', (data) => {
  players = data.players;
  foods = data.foods;
});

canvas.addEventListener('mousemove', (e) => {
  mouseX = e.clientX;
  mouseY = e.clientY;
});

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (players[myId]) {
    const me = players[myId];
    cameraX = me.x - canvas.width / 2;
    cameraY = me.y - canvas.height / 2;

    // Send movement
    const targetX = cameraX + mouseX;
    const targetY = cameraY + mouseY;
    socket.emit('playerMove', { x: targetX, y: targetY });
  }

  // Draw grid
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 1;
  const gridSize = 50;
  for (let x = -cameraX % gridSize; x < canvas.width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = -cameraY % gridSize; y < canvas.height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // Draw foods
  foods.forEach(food => {
    ctx.fillStyle = food.color;
    ctx.beginPath();
    ctx.arc(food.x - cameraX, food.y - cameraY, 6, 0, Math.PI * 2);
    ctx.fill();
  });

  // Draw players
  Object.values(players).forEach(player => {
    ctx.fillStyle = player.color;
    ctx.beginPath();
    ctx.arc(player.x - cameraX, player.y - cameraY, player.radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'white';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(player.name, player.x - cameraX, player.y - cameraY + 5);
  });

  requestAnimationFrame(gameLoop);
}

gameLoop();