require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.json());
app.use(express.static('public'));

// MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

const User = require('./models/User');

// Game state
const players = {};
const foods = [];
const WORLD_SIZE = 3000;

// Generate food
for (let i = 0; i < 300; i++) {
  foods.push({
    x: Math.random() * WORLD_SIZE,
    y: Math.random() * WORLD_SIZE,
    color: `hsl(${Math.random()*360}, 80%, 60%)`
  });
}

io.on('connection', (socket) => {
  console.log('Player connected:', socket.id);

  players[socket.id] = {
    id: socket.id,
    name: "Гравець",
    x: WORLD_SIZE / 2,
    y: WORLD_SIZE / 2,
    radius: 25,
    mass: 25,
    color: `hsl(${Math.random()*360}, 80%, 60%)`
  };

  socket.emit('init', { id: socket.id, foods });

  socket.on('setName', (name) => {
    if (players[socket.id]) players[socket.id].name = name.slice(0, 20);
  });

  socket.on('playerMove', (data) => {
    if (players[socket.id]) {
      players[socket.id].x = data.x;
      players[socket.id].y = data.y;
    }
  });

  socket.on('disconnect', () => {
    delete players[socket.id];
  });
});

// Game loop
setInterval(() => {
  io.emit('gameState', { players, foods });
}, 45);

server.listen(process.env.PORT || 3000, () => {
  console.log(`Server running on port ${process.env.PORT || 3000}`);
});